package com.example.loginf2.navegation

sealed class NavRoutes(val route: String) {
    object Home : NavRoutes("Pant1")
    object Regresar : NavRoutes("LoginScreen")

    object HomeP : NavRoutes("Home2")

    object Login : NavRoutes("LoginScreen")
    object Insertar : NavRoutes("AddMovie")
}









