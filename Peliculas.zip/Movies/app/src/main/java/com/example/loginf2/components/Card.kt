package com.example.loginf2.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.loginf2.navegation.NavRoutes
import com.example.loginf2.ui.theme.Shapes

@Composable
fun Card(navController: NavController, img: String, titulo: String, fecha: String, descripcion: String) {
    var lineas by rememberSaveable { mutableStateOf(false) }
    Spacer(modifier = Modifier.height(10.dp))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(3.dp, MaterialTheme.colors.primary, Shapes.small)
            .clip(Shapes.small)
            .background(MaterialTheme.colors.primaryVariant)
            .clickable { navController.navigate(NavRoutes.Movie3.createRoute(img, titulo, descripcion)) },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = rememberAsyncImagePainter(img),
            contentDescription = "Poster_Pelicula",
            modifier = Modifier
                .width(130.dp)
                .height(200.dp)
        )
        Column(
            modifier = Modifier
                .background(MaterialTheme.colors.primaryVariant)
                .width(500.dp)
                .padding(all = 10.dp)
        ) {
            Text(
                text = titulo,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = Color.Black
                )
            )

            Text(text = fecha, color = Color.Black)
            Text(
                maxLines = if (lineas) Int.MAX_VALUE else 4,
                style = TextStyle(color = MaterialTheme.colors.onSecondary),
                textAlign = TextAlign.Justify,
                text = descripcion
            )

            if (lineas) {
                Row(
                    modifier = Modifier
                        .width(500.dp)
                        .padding(2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Text(
                        text = "Editar",
                        modifier = Modifier
                            .background(MaterialTheme.colors.onError)
                            .padding(3.dp)
                            .border(3.dp, Color.Transparent, Shapes.small)
                            .clip(Shapes.small),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Eliminar",
                        modifier = Modifier
                            .background(MaterialTheme.colors.error)
                            .padding(3.dp)
                            .border(3.dp, Color.Transparent, Shapes.large)
                            .clip(Shapes.large),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }

    Spacer(modifier = Modifier.height(6.dp))
}