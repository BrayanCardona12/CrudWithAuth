package com.example.loginf2.models

import androidx.annotation.StringRes

data class LoginState(
    val algo:String = "",
    val nombre:String = "",
    val num:String = "",
    val img:String = "",
    val successLogin:Boolean = true,
    @StringRes val errorMessages: Int? = null

)
