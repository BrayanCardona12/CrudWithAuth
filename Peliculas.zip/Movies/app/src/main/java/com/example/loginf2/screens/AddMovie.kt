package com.example.loginf2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.loginf2.models.Movies
import com.example.loginf2.navegation.NavRoutes
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddMovie(navController: NavController) {
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                modifier = Modifier.size(42.dp),
                onClick = { navController.navigate(NavRoutes.Home.route) }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Agregar",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent(navController)
    }
}

@Composable
fun BodyContent(navController: NavController) {
    var movieNombre by remember { mutableStateOf("") }
    var movieImg by remember { mutableStateOf("") }
    var movieDesc by remember { mutableStateOf("") }
    var movieFecha by remember { mutableStateOf("") }
    var validar by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.secondary)
            .padding(50.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "INSERT",
                modifier = Modifier
                    .fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontSize = MaterialTheme.typography.h2.fontSize,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.primary
            )
            TextField(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Transparent),
                value = movieNombre,
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                onValueChange = { movieNombre = it },
                label = { Text(text = "Nombre:") })
            Spacer(modifier = Modifier.height(20.dp))


            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = movieFecha,
                onValueChange = { movieFecha = it },
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                label = { Text(text = "Fecha:") })
            Spacer(modifier = Modifier.height(20.dp))

            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = movieImg,
                onValueChange = { movieImg = it },
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                label = { Text(text = "Img:") })
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value = movieDesc,
                textStyle = TextStyle(color = MaterialTheme.colors.onSurface),
                onValueChange = { movieDesc = it },
                label = { Text(text = "Descripción:") })
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    if (movieDesc == "" || movieImg == "" || movieFecha == "" || movieNombre == "") {
                        validar = true
                    } else {
                        val movies = Movies(movieImg, movieNombre, movieFecha, movieDesc)

                        Firebase.firestore.collection("movies").add(movies)


                        navController.navigate(NavRoutes.Home.route)
                    }

                },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
            ) {
                Text(text = "Añadir Pelicula", color = MaterialTheme.colors.secondary)
            }

            if (validar) {
                Text(
                    text = "Error, por favor llena todos los campos",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colors.error,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    fontSize = 20.sp
                )
            }

        }
    }

}