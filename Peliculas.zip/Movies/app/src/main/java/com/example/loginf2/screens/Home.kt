package com.example.loginf2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.loginf2.models.MoviesViewModel
import com.example.loginf2.navegation.NavRoutes
import com.example.loginf2.components.Card
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Pant1(
    navController: NavController,
    algo: String,
    email: String,
    img: String,
    onLoginClick: () -> Unit,
    moviesViewModel: MoviesViewModel
) {
    class BtnRegresar : ViewModel() {
        fun Algo() {
            viewModelScope.launch {
                onLoginClick()
                delay(2000)
                navController.navigate(NavRoutes.Login.route)
            }
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                modifier = Modifier.size(42.dp),
                onClick = { navController.navigate(NavRoutes.Insertar.route) }) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription = "Agregar",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )

            } // fin del FloatingActionButton
        }, // fin del floatingActionButton
        floatingActionButtonPosition = FabPosition.End,
        topBar = {
            Column() {
                Row(
                    modifier = Modifier
                        .background(MaterialTheme.colors.secondary)
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(img),
                        contentDescription = "photo_perfil",
                        modifier = Modifier
                            .size(85.dp)
                            .border(3.dp, MaterialTheme.colors.onSecondary, CircleShape)
                            .clip(CircleShape)
                    )
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            style = TextStyle(
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            ),
                            text = algo,
                            fontSize = 25.sp,
                            color = MaterialTheme.colors.onSecondary
                        )
                        Text(
                            text = email,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colors.onSecondary
                        )
                    }

                }
                Spacer(
                    modifier = Modifier
                        .height(3.dp)
                        .fillMaxWidth()
                        .background(MaterialTheme.colors.primary)
                )
            }


        }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.secondary)
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            items(moviesViewModel.movies.value) { datos ->
                Card(navController ,datos.img, datos.nombre, datos.fecha,datos.descripcion)
            }
            item {
                Button(onClick = { BtnRegresar().Algo() }) {
                    Text(text = "Cerrar Sección", color = MaterialTheme.colors.secondary)
                }
            }
        }

    }


    // Card("https://www.lahiguera.net/cinemania/pelicula/10179/el_gato_con_botas_el_ultimo_deseo-cartel-10596.jpg")
    // Card("https://farandula.co/wp-content/uploads/2022/08/Poster-AVATAR-scaled.jpg")
    // Card("https://m.media-amazon.com/images/M/MV5BZWMyYzFjYTYtNTRjYi00OGExLWE2YzgtOGRmYjAxZTU3NzBiXkEyXkFqcGdeQXVyMzQ0MzA0NTM@._V1_FMjpg_UX1000_.jpg")

}







